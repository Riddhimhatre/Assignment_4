# Assignment4_CS612
<b>!!!...Indian Festivals...!!!</b></br></br>
This is a Single Page Application for few blog posts of Indian Festivals.</br>
I have explained 3 festivals of India.after clicking on the title we will be redirected to the main blog posts which will also
display date and the same image, that will replace the home page.</br>
Once we click on the festival name, it will redirect us to home page.</br>
Included Navigation bar, displays Google's Top headlines, which is done by using API</br></br>
<b>For Running the app : </b></br></br>
1.Click on Clone or Download.</br>
2.Click on Download Zip file.</br>
3.Make a new folder, name it as per your wish and Extract the downloaded zip in that folder.</br>
4.Open Command Prompt and navigate to the root directory of the extracted file.</br>
5.Type in command "npm install". This will install all node modules necessary to run the app.</br>
6.After all node modules are installed properly, run the command "npm start".</br>
7.This will initiate app and you can see the Single Page Application on localhost:3000</br></br>
