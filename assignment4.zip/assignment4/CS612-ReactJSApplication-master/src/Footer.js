import React, { Component } from 'react';

class Footer extends Component {
  render() {
    return (
     <footer>
     <center>Copyright &copy; tj66198n@pace.edu</center>
     </footer>
    );
  }
}

export default Footer;